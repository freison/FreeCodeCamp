﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SearchDAO;

namespace SearchApp
{
    public partial class Registro : System.Web.UI.Page
    {
        private LoginDAO oLoginDAO = new LoginDAO();
        SqlDataReader leer;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnRegistrar_Click(object sender, EventArgs e)
        {
            int c = 0;
            int c1 = 0;
            int ar = 0;

            foreach (var i in TxtUsuario.Text.Trim())
            {
                if (i == ' ')
                {
                    c++;
                }
            }

            foreach (var i in TxtCorreo.Text.Trim())
            {
                if (i == ' ')
                {
                    c1++;
                }
                else if (i == '@')
                {
                    ar++;
                }
            }

            if (c > 0 || TxtUsuario.Text == "" || TxtUsuario.Text.Trim().Length < 4)
            {
                LbUsuario.Text = "Debe de ingresar un nombre válido.";
                LbCorreo.Text = "";
                LbClave.Text = "";
                LbRepetir.Text = "";
            }
            else if (c1 > 0 || TxtCorreo.Text == "" || TxtCorreo.Text.Trim().Length < 10 || ar != 1)
            {
                LbCorreo.Text = "Debe de ingresar un correo válido.";
                LbUsuario.Text = "";
                LbClave.Text = "";
                LbRepetir.Text = "";
            }
            else if (TxtClave.Text.Trim().Length < 6)
            {
                LbClave.Text = "Debe de ingresar una contraseña de al menos 6 carácteres.";
                LbUsuario.Text = "";
                LbCorreo.Text = "";
                LbRepetir.Text = "";
            }
            else if(TxtClave.Text.Trim() != TxtRepetir.Text.Trim())
            {
                LbRepetir.Text = "Las contraseñas no coinciden.";
                LbUsuario.Text = "";
                LbCorreo.Text = "";
                LbClave.Text = "";
            }

            else
            {
                oLoginDAO.Agregar(TxtUsuario.Text.Trim(), TxtCorreo.Text.Trim(), TxtClave.Text.Trim(), TxtUsuario.Text.Trim(), 1, 0);
            }
        }
    }
}
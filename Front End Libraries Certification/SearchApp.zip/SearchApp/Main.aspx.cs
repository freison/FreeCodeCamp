﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SearchDAO;

namespace SearchApp
{
    public partial class Main : System.Web.UI.Page
    {
        private LoginDAO oLoginDAO = new LoginDAO();
        private SqlDataReader leer;
        protected void Page_Load(object sender, EventArgs e)
        {
            //string usuario = Request.QueryString["dato"];
            //LbUsuario.Text = usuario;
            try
            {
                leer = oLoginDAO.Buscar((String)Session["Usuario"]);
                if (leer.Read())
                {
                    LbUsuario.Text = (String)Session["Usuario"];
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }
            catch(Exception ex)
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}
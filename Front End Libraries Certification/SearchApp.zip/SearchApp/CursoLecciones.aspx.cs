﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;

namespace SearchApp
{
    public partial class CursoLecciones : System.Web.UI.Page
    {
        public int n = 2;
        public string Source = "Naive.mp4";
        protected void Page_Load(object sender, EventArgs e)
        {
            string path = "Naive.mp4";

            using (FileStream streamWriter = File.Create(path))
            {
                
            }
        }
    }
}
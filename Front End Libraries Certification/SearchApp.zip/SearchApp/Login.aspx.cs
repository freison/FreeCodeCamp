﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using SearchDAO;

namespace SearchApp
{
    public partial class Login : System.Web.UI.Page
    {
        private LoginDAO oLoginDAO = new LoginDAO();
        SqlDataReader leer;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //TxtEmail.Text = TxtEmail.Text + "yes";
            leer = oLoginDAO.IniciarSesion(TxtEmail.Text.Trim(), TxtPass.Text.Trim());
            if (leer.Read())
            {
                Session["Usuario"] = TxtEmail.Text.Trim();
                //TxtEmail.Text = "Se encontro al usuario.";
                //System.Diagnostics.Process.Start("Chrome.exe", "www.google.com");
                Response.Redirect("Main.aspx?dato=" + TxtEmail.Text.Trim());
            }
            else
            {
                TxtEmail.Text = "No se encontro ningun usuario con los datos ingresados.";
            }
        }
    }
}
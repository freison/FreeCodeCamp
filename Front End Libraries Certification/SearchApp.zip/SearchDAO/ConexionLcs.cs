﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace SearchDAO
{
    public class ConexionLcs
    {
        SqlConnection conexion = new SqlConnection("Data Source=40.113.228.156;Initial Catalog=SearchApp;User ID=Freison;Password=FReisoncastro.123");
        SqlCommand cmd;
        SqlDataReader dr;

        public SqlConnection AbrirConexion()
        {
            if (conexion.State == ConnectionState.Closed)
            {
                conexion.Open();
            }

            return conexion;
        }

        public SqlConnection CerrarConexion()
        {
            if (conexion.State == ConnectionState.Open)
            {
                conexion.Close();
            }

            return conexion;
        }
    }
}

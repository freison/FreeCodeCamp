﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace SearchDAO
{
    public class LoginDAO
    {
        private ConexionLcs conexion = new ConexionLcs();
        private SqlDataReader leer;
        private string ClaveMaestra = "ProgDB2016";
        public DataTable dt = new DataTable();

        public SqlDataReader IniciarSesion(string usuario, string clave)
        {
            SqlCommand comand = new SqlCommand("Sp_Login", conexion.AbrirConexion());
            comand.CommandType = CommandType.StoredProcedure;
            comand.Parameters.AddWithValue("@Usuario", Encriptar(usuario));
            comand.Parameters.AddWithValue("@Clave", Encriptar(clave));
            leer = comand.ExecuteReader();

            return leer;
        }

        public void Agregar(string nombreusuario, string correo, string clave, string nombrecompleto, int metodoDePagoId, int acceso)
        {
            var l = BuscarUltimo();
            if(l.Read())
            {
                string u = Convert.ToString(l.GetInt32(0) + 1);
                SqlCommand command = new SqlCommand("Insert into Usuarios values('" + u + "', '"+Encriptar(nombreusuario)+"', '"+correo+"', '"+Encriptar(clave)+"', '"+nombrecompleto+"', '"+metodoDePagoId+"', '"+acceso+"')", conexion.AbrirConexion());
                command.ExecuteNonQuery();
            }
            else
            {
                l.Close();
                string u = "1";
                SqlCommand command = new SqlCommand("Insert into Usuarios values('" + u + "', '" + Encriptar(nombreusuario) + "', '" + correo + "', '" + Encriptar(clave) + "', '" + nombrecompleto + "', '" + metodoDePagoId + "', '" + acceso + "')", conexion.AbrirConexion());
                command.ExecuteNonQuery();
            }
        }

        public SqlDataReader BuscarUltimo()
        {
            SqlCommand command = new SqlCommand("Select top(1) * from Usuarios order by Id desc", conexion.AbrirConexion());
            leer = command.ExecuteReader();

            return leer;
        }

        public SqlDataReader Buscar(string usuario)
        {
            SqlCommand command = new SqlCommand("select * from Usuarios where NombreDeUsuario = '" + Encriptar(usuario) + "'", conexion.AbrirConexion());
            leer = command.ExecuteReader();

            return leer;
        }

        public string Encriptar(string cadena)
        {
            byte[] arrMaestro;
            byte[] arrCifrar = UTF8Encoding.UTF8.GetBytes(cadena);
            MD5CryptoServiceProvider varMd5 = new MD5CryptoServiceProvider();
            arrMaestro = varMd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(ClaveMaestra));
            varMd5.Clear();
            //algoritmo 3das
            TripleDESCryptoServiceProvider tDes = new TripleDESCryptoServiceProvider();
            tDes.Key = arrMaestro;
            tDes.Mode = CipherMode.ECB;
            tDes.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransformadore = tDes.CreateEncryptor();
            byte[] Resultado = cTransformadore.TransformFinalBlock(arrCifrar, 0, arrCifrar.Length);
            tDes.Clear();
            return (Convert.ToBase64String(Resultado, 0, Resultado.Length));
        }//fin de encriptar

        public string Desencriptar(string textoEncriptado)
        {
            byte[] arrClave;
            byte[] arrDesifrar = Convert.FromBase64String(textoEncriptado);
            MD5CryptoServiceProvider varMd5 = new MD5CryptoServiceProvider();
            arrClave = varMd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(ClaveMaestra));
            varMd5.Clear();
            TripleDESCryptoServiceProvider tDes = new TripleDESCryptoServiceProvider();
            tDes.Key = arrClave;
            tDes.Mode = CipherMode.ECB;
            tDes.Padding = PaddingMode.PKCS7;
            ICryptoTransform Transformador = tDes.CreateDecryptor();
            byte[] resultado = Transformador.TransformFinalBlock(arrDesifrar, 0, arrDesifrar.Length);
            tDes.Clear();
            return (UTF8Encoding.UTF8.GetString(resultado));
        }
    }
}
